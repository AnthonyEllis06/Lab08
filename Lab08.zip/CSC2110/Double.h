#if !defined (DOUBLE_H)
#define DOUBLE_H

namespace CSC2110
{
class Double
{
   private:
      double value;

   public:
      Double(double val);
      ~Double();
      double getValue();
};
}

#endif
